import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';
import { View } from './pages/view/view';
import { Cart } from './pages/cart/cart';
import { Home } from './pages/home/home';
import { RouterModule } from '@angular/router';
import { routes } from './app.routes';  


@Component({
  selector: 'app-root',
  imports: [RouterOutlet],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('products');
}
