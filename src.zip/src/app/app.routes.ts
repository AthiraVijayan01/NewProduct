import { Routes } from '@angular/router';

import{ View } from './pages/view/view';
import { Home } from './pages/home/home';
import { Cart } from './pages/cart/cart';

export const routes: Routes = [
    { path: '', redirectTo: 'home', pathMatch: 'full' }, 
    { path: 'home', component: Home },
    {path:'view',component:View} ,
    {path:'cart',component:Cart},
    
];
