import { Component, OnInit } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { Router } from '@angular/router';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { findIndex } from 'rxjs';


interface Product {
  name: string;
  price: number;
  category: string;
}

@Component({
  selector: 'app-view',
  imports: [RouterModule, CommonModule, HttpClientModule, FormsModule],
  templateUrl: './view.html',
  styleUrl: './view.css',
})
export class View implements OnInit {

  goback(){
    this.router.navigate(['/home']);
  }

  addtocart(){
    this.router.navigate(['/cart']);

  }

productslist:any[]=[];

showModal=false;
isEditMode = false;
noResults= false;



constructor(private router: Router, private http: HttpClient) {}
  
ngOnInit():void{
  console.log("Helloo"); 
  this.getproducts();
}

newproduct={
  name:'',
  category:'',
  price:0
}


openModal(){
  this.showModal=true;
}



resetModal(){
  this.newproduct={name:'', price:0, category:''};
  this.showModal=false;
  
}

closeModal() {
    this.showModal = false;
  }

  getproducts() {

  const localData = localStorage.getItem('data');
  if (localData) {
    this.productslist= JSON.parse(localData);
  } else {
    this.http.get('/datas.json').subscribe({
      next: (data: any) => {
        this.productslist = data;
        localStorage.setItem('data', JSON.stringify(this.productslist));
      }
    });
  }

}

  addProduct() {

  const product = { 
    ...this.newproduct, //create new product object using spread operator ,copy the properties
    id: this.productslist.length + 1, //product list length
  };
  this.productslist.push(product); // pushes the new one to productlist 
  localStorage.setItem('data', JSON.stringify(this.productslist)); //save to storage
  this.resetModal();
}


deleteProduct(name: string) {
  this.productslist = this.productslist.filter(p => p.name !== name );
  localStorage.setItem('data', JSON.stringify(this.productslist));
}


openEditModal(product: Product) {
    this.isEditMode = true;
    this.showModal = true;
  }

updateProduct() {
    const n = this.productslist.findIndex(u => u.name === this.newproduct.name);
    if (n !== -1) {
      this.productslist[n] = { ...this.newproduct };
      localStorage.setItem('data', JSON.stringify(this.productslist));
    }

    this.closeModal();
  }


}
 
