import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Router, RouterModule, RouterOutlet } from '@angular/router';
import { HttpClient ,HttpClientModule } from '@angular/common/http';


interface cart{
  name: string;
  price: number;
  category: string;
}

@Component({
  selector: 'app-cart',
  imports: [RouterModule,CommonModule,HttpClientModule],
  templateUrl: './cart.html',
  styleUrl: './cart.css',
})
export class Cart {
  constructor(private router: Router, private http: HttpClient) {}

  cartlist:any[]=[];
  grandTotal: number = 0;
  
  newcart={
  name:'',
  category:'',
  price:0
}


  goback(){
    this.router.navigate(['/home']);
  }

  calculate(){
    this.grandTotal = this.cartlist.reduce((s,p,q,r) => s + (p.price * p.), 0);
  }

  updatecart(item: Cart, qty: number){
    if(qty=>1){
    localStorage.setItem('cart', JSON.stringify(this.cartlist));
    this.calculate();
  }

}
}
